2D Character Animation

Editor tools and runtime scripts to support the authoring of 2D Animated Characters.  

Editor Tooling
- Skinning Editor
  - Available through Sprite Editor Window module
  - Bone tools allow creation of bind poses easily. Supports flexible setup of complex hierarchy.
  - Mesh tools allow auto mesh tesselation or manual tesselation
  - Weight tools allow auto weight calculation and weight painting


Runtime Support
- SpriteSkin deformation
- 2D IK